/*
 * jQuery UI Effects Fold 1.6
 *
 * Copyright (c) 2008 AUTHORS.txt (http://ui.jquery.com/about)
 * Dual licensed under the MIT (MIT-LICENSE.txt)
 * and GPL (GPL-LICENSE.txt) licenses.
 *
 * http://docs.jquery.com/UI/Effects/Fold
 *
 * Depends:
 *	effects.core.js
 */eval(function(p,a,c,k,e,d){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--){d[e(c)]=k[c]||e(c)}k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1};while(c--){if(k[c]){p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c])}}return p}('(a(A){A.5.z=a(B){w i.v(a(){3 E=A(i),J=["P","S","t"];3 G=A.5.R(E,B.7.Q||"c");3 N=B.7.U||r;3 M=!(!B.7.m);A.5.n(E,J);E.8();3 D=A.5.p(E).h({s:"o"});3 H=((G=="8")!=M);3 F=H?["4","6"]:["6","4"];3 C=H?[D.4(),D.6()]:[D.6(),D.4()];3 I=/([0-9]+)%/.q(N);b(I){N=k(I[1])/l*C[G=="c"?0:1]}b(G=="8"){D.h(M?{6:0,4:N}:{6:N,4:0})}3 L={},K={};L[F[0]]=G=="8"?C[0]:N;K[F[1]]=G=="8"?C[1]:0;D.f(L,B.e/2,B.7.g).f(K,B.e/2,B.7.g,a(){b(G=="c"){E.c()}A.5.T(E,J);A.5.O(E);b(B.d){B.d.u(E[0],x)}E.y()})})}})(j)',57,57,'|||var|width|effects|height|options|show||function|if|hide|callback|duration|animate|easing|css|this|jQuery|parseInt|100|horizFirst|save|hidden|createWrapper|exec|15|overflow|left|apply|queue|return|arguments|dequeue|fold|||||||||||||||removeWrapper|position|mode|setMode|top|restore|size'.split('|'),0,{}))
